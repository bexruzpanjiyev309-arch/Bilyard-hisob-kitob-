// BILYARD PRO ULTRA — one-time, one-phone, lifetime license binding.
// Deploy with Firebase Functions (requires Blaze for callable Cloud Functions).
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const crypto = require('crypto');
initializeApp();
const db = getFirestore();
const REGION = 'asia-south1';
const hash = value => crypto.createHash('sha256').update(String(value).trim().toUpperCase()).digest('hex');
function requireAdmin(req) {
  if (!req.auth || req.auth.token.licenseAdmin !== true) throw new HttpsError('permission-denied', 'Faqat litsenziya administratori.');
}

// A key can be activated once. Reinstalling on the SAME Android device can
// recover its entitlement; another device is always rejected.
exports.activateLicense = onCall({ region: REGION }, async (req) => {
  const key = String(req.data?.licenseKey || '').trim();
  const deviceId = String(req.data?.deviceId || '').trim();
  if (!key || !/^[a-f0-9]{16,128}$/i.test(deviceId)) throw new HttpsError('invalid-argument', 'Kalit yoki qurilma identifikatori noto‘g‘ri.');
  const ref = db.collection('licenses').doc(hash(key));
  return await db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    if (!snap.exists) return { valid:false, reason:'not_found' };
    const d = snap.data();
    if (d.active !== true) return { valid:false, reason:'blocked' };
    if (d.boundDeviceHash && d.boundDeviceHash !== hash(deviceId)) return { valid:false, reason:'already_used' };
    if (!d.boundDeviceHash) tx.update(ref, { boundDeviceHash:hash(deviceId), activatedAt:FieldValue.serverTimestamp() });
    return { valid:true, lifetime:true, customerName:d.customerName || '' };
  });
});

exports.createLicense = onCall({ region: REGION }, async (req) => {
  requireAdmin(req);
  const customerName = String(req.data?.customerName || '').trim();
  if (!customerName) throw new HttpsError('invalid-argument', 'Mijoz nomini kiriting.');
  const key = 'BPU-' + crypto.randomBytes(4).toString('hex').toUpperCase() + '-' + crypto.randomBytes(4).toString('hex').toUpperCase() + '-' + crypto.randomBytes(4).toString('hex').toUpperCase();
  const ref = db.collection('licenses').doc(hash(key));
  await ref.set({ customerName, active:true, lifetime:true, createdAt:FieldValue.serverTimestamp(), createdBy:req.auth.uid, boundDeviceHash:null, activatedAt:null });
  return { licenseKey:key, customerName, lifetime:true };
});
exports.setLicenseActive = onCall({ region: REGION }, async (req) => {
  requireAdmin(req);
  const key = String(req.data?.licenseKey || '').trim();
  if (!key || typeof req.data?.active !== 'boolean') throw new HttpsError('invalid-argument', 'Kalit va active holati kerak.');
  const ref = db.collection('licenses').doc(hash(key));
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'Kalit topilmadi.');
  await ref.update({ active:req.data.active, updatedAt:FieldValue.serverTimestamp() });
  return { success:true, active:req.data.active };
});
exports.listLicenses = onCall({ region: REGION }, async (req) => {
  requireAdmin(req);
  const snap = await db.collection('licenses').orderBy('createdAt','desc').limit(200).get();
  return { licenses:snap.docs.map(x => { const d=x.data(); return { customerName:d.customerName, active:d.active, lifetime:true, activated:!!d.boundDeviceHash, createdAt:d.createdAt?.toDate().toISOString() || null }; }) };
});
