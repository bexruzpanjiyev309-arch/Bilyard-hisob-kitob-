BILYARD PRO ULTRA 3.7.5

Yangilanishlar:
- Stol/seans yopilganda qora-yashil-oltin uslubdagi chek oynasi.
- Chekda joy nomi, sana-vaqt, o‘yin davomiyligi, xizmat puli, mahsulotlar va jami summa.
- Chekni chop etish A4 sahifaga moslangan.
- Qarz to‘lovi va mijozni o‘chirish uchun ilova ichidagi premium modal oynalar.
- Mijoz tanlab o‘ynalgan seanslar uchun mijoz ismi, telefon raqami, joy nomi, sana-vaqt va summa bilan tarix.
- Kunlik/haftalik hisobot chop etish A4 portret sahifa o‘lchamiga moslangan.

Eslatma:
- Vaqt hisoblash funksiyasi o‘zgartirilmadi.
- Login/parol yoki serverli kuzatuv qo‘shilmadi.
- Mijoz qarziga seans summasi avtomatik qo‘shilmaydi: mijoz tanlash faqat o‘yin tarixiga bog‘lanadi; qarz summasi mavjud qarz kiritish/to‘lov jarayoni orqali yuritiladi.
- APK qurilishi ushbu muhitda sinovdan o‘tkazilmadi (Gradle mavjud emas). GitHub Actions orqali yig‘ilgach, qurilma testini bajaring.


LITSENZIYA BACKENDI: ADMIN_SETUP_UZ.txt faylini o‘qing. Android APK litsenziya tekshiruviga hali ulanmagan.


BOSQICH 2 — ANDROID LITSENZIYA OYNASI
- Ilova endi birinchi ishga tushganda litsenziya kalitini so‘raydi.
- activateLicense callable Cloud Function bilan bog‘lanadi (asia-south1).
- Muvaffaqiyatli faollashgandan so‘ng lokal belgi saqlanadi va ilova keyingi ochilishlarda to‘g‘ridan-to‘g‘ri ishga tushadi.
- Bu bosqichning ishlashi uchun functions/ ichidagi server kodini Firebase'ga deploy qilish shart. Cloud Functions deploy odatda Blaze billing talab qiladi.
- Android ilovasini o‘chirishda SharedPreferences o‘chadi; shu sabab qayta o‘rnatishdan keyin qayta faollashtirish so‘ralishi mumkin. Server ayni ANDROID_ID bo‘lsa eski qurilmaga qayta ruxsat beradi, boshqa telefonga bermaydi.
- Bu ZIP hali build/test qilinmagan; Firebase serveriga deploy qilinmagan.
