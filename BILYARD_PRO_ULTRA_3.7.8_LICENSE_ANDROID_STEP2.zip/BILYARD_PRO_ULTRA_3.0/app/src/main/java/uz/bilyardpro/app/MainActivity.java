package uz.bilyardpro.app;

import android.app.Activity;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.Context;
import android.content.SharedPreferences;
import android.print.PrintManager;
import android.print.PrintAttributes;
import com.google.firebase.FirebaseApp;
import com.google.firebase.functions.FirebaseFunctions;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView web;
    private boolean shown = false;
    private FirebaseFunctions functions;
    private SharedPreferences prefs;
    private String deviceId;

    public class PrintBridge {
        @JavascriptInterface public void printPage(String title) {
            runOnUiThread(() -> {
                if (web == null) return;
                PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (manager == null) return;
                String jobName = (title == null || title.trim().isEmpty()) ? "BILYARD PRO ULTRA" : title;
                android.print.PrintDocumentAdapter adapter = web.createPrintDocumentAdapter(jobName);
                PrintAttributes attributes = new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("bilyard", "BILYARD", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
                manager.print(jobName, adapter, attributes);
            });
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(3,22,14));
        getWindow().setNavigationBarColor(Color.rgb(3,22,14));
        prefs = getSharedPreferences("bpu_license", MODE_PRIVATE);
        deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        if (deviceId == null) deviceId = "unknown-device";
        try { FirebaseApp.initializeApp(this); functions = FirebaseFunctions.getInstance("asia-south1"); }
        catch (Exception e) { functions = null; }
        if (prefs.getBoolean("activated", false)) { showApp(); }
        else showLicenseScreen();
    }

    private void showLicenseScreen() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER); root.setPadding(28,28,28,28); root.setBackgroundColor(Color.rgb(6,20,14));
        TextView title = new TextView(this); title.setText("BILYARD PRO ULTRA"); title.setTextColor(Color.rgb(232,200,111)); title.setTextSize(24); title.setGravity(Gravity.CENTER); title.setPadding(0,0,0,18); root.addView(title);
        TextView info = new TextView(this); info.setText("Umrbod litsenziyani faollashtirish uchun kalitni kiriting. Bir kalit faqat bitta telefonga biriktiriladi."); info.setTextColor(Color.WHITE); info.setTextSize(16); info.setGravity(Gravity.CENTER); info.setPadding(0,0,0,20); root.addView(info);
        EditText key = new EditText(this); key.setSingleLine(true); key.setHint("BPU-XXXX-XXXX-XXXX"); key.setTextColor(Color.WHITE); key.setHintTextColor(Color.GRAY); key.setPadding(16,12,16,12); root.addView(key, new LinearLayout.LayoutParams(-1,-2));
        Button activate = new Button(this); activate.setText("FAOLLASHTIRISH"); root.addView(activate);
        TextView status = new TextView(this); status.setTextColor(Color.rgb(255,190,130)); status.setGravity(Gravity.CENTER); status.setPadding(0,16,0,0); root.addView(status);
        setContentView(root);
        activate.setOnClickListener(v -> {
            String licenseKey = key.getText().toString().trim();
            if (licenseKey.isEmpty()) { status.setText("Litsenziya kalitini kiriting."); return; }
            if (functions == null) { status.setText("Firebase sozlamasi topilmadi. Internet va Firebase konfiguratsiyasini tekshiring."); return; }
            activate.setEnabled(false); status.setText("Kalit tekshirilmoqda...");
            Map<String,Object> data = new HashMap<>(); data.put("licenseKey", licenseKey); data.put("deviceId", deviceId);
            functions.getHttpsCallable("activateLicense").call(data).addOnCompleteListener(task -> {
                activate.setEnabled(true);
                if (!task.isSuccessful()) { status.setText("Server bilan bog‘lanib bo‘lmadi. Internetni tekshiring."); return; }
                Object result = task.getResult().getData();
                if (!(result instanceof Map)) { status.setText("Server javobi noto‘g‘ri."); return; }
                Map<?,?> response = (Map<?,?>) result;
                if (Boolean.TRUE.equals(response.get("valid"))) {
                    prefs.edit().putBoolean("activated", true).putString("customer", String.valueOf(response.get("customerName"))).apply();
                    showApp();
                } else {
                    String reason = String.valueOf(response.get("reason"));
                    if ("already_used".equals(reason)) status.setText("Bu kalit boshqa telefonda ishlatilgan.");
                    else if ("blocked".equals(reason)) status.setText("Bu litsenziya bloklangan.");
                    else status.setText("Kalit topilmadi. To‘g‘ri kalitni kiriting.");
                }
            });
        });
    }

    private void showApp() {
        ImageView splash = new ImageView(this); splash.setImageResource(uz.bilyardpro.app.R.drawable.splash_cover); splash.setScaleType(ImageView.ScaleType.CENTER_CROP); setContentView(splash);
        web = new WebView(this); web.setBackgroundColor(Color.rgb(3,22,14)); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setAllowFileAccess(true);
        web.addJavascriptInterface(new PrintBridge(), "AndroidPrint"); web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() { @Override public void onPageFinished(WebView v, String url) { if (!shown) { shown = true; setContentView(web); } } });
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }
}
