BILYARD PRO ULTRA 3.7.5

Yangilanishlar:
- Stol/seans yopilganda qora-yashil-oltin uslubdagi chek oynasi.
- Chekda joy nomi, sana-vaqt, o‘yin davomiyligi, xizmat puli, mahsulotlar va jami summa.
- Chekni chop etish A4 sahifaga moslangan.
- Qarz to‘lovi va mijozni o‘chirish uchun ilova ichidagi premium modal oynalar.
- Mijoz tanlab o‘ynalgan seanslar uchun mijoz ismi, telefon raqami, joy nomi, sana-vaqt va summa bilan tarix.
- Kunlik/haftalik hisobot chop etish A4 portret sahifa o‘lchamiga moslangan.

Eslatma:
- Vaqt hisoblash funksiyasi o‘zgartirilmadi.
- Login/parol yoki serverli kuzatuv qo‘shilmadi.
- Mijoz qarziga seans summasi avtomatik qo‘shilmaydi: mijoz tanlash faqat o‘yin tarixiga bog‘lanadi; qarz summasi mavjud qarz kiritish/to‘lov jarayoni orqali yuritiladi.
- APK qurilishi ushbu muhitda sinovdan o‘tkazilmadi (Gradle mavjud emas). GitHub Actions orqali yig‘ilgach, qurilma testini bajaring.
