package uz.bilyardpro.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.graphics.Color;
import android.widget.ImageView;
import android.print.PrintManager;
import android.content.Context;
import android.print.PrintAttributes;

public class MainActivity extends Activity {
    private WebView web;
    private boolean shown = false;

    public class PrintBridge {
        @JavascriptInterface
        public void printPage(String title) {
            runOnUiThread(() -> {
                if (web == null) return;
                PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (manager == null) return;
                String jobName = (title == null || title.trim().isEmpty()) ? "BILYARD PRO ULTRA" : title;
                android.print.PrintDocumentAdapter adapter = web.createPrintDocumentAdapter(jobName);
                PrintAttributes attributes = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("bilyard", "BILYARD", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();
                manager.print(jobName, adapter, attributes);
            });
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(3,22,14));
        getWindow().setNavigationBarColor(Color.rgb(3,22,14));
        ImageView splash = new ImageView(this);
        splash.setImageResource(uz.bilyardpro.app.R.drawable.splash_cover);
        splash.setScaleType(ImageView.ScaleType.CENTER_CROP);
        setContentView(splash);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(3,22,14));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) {
                if (!shown) { shown = true; setContentView(web); }
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
