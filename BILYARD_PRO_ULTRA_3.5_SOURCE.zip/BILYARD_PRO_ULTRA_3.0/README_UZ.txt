BILYARD PRO ULTRA 3.0 — Android WebView loyiha manbasi

GitHub orqali APK:
1) ZIP ichidagi barcha fayl/papkalarni repository root'iga joylang.
2) GitHub -> Actions -> Build BILYARD PRO ULTRA 3.0 -> Run workflow.
3) Ish muvaffaqiyatli tugasa, BILYARD-PRO-ULTRA-3-APK artifact'ini yuklab oling.

Muhim cheklovlar:
- Ilova hozircha offline, ma'lumotlar Android WebView localStorage'ida saqlanadi. Ilovani o'chirish yoki ma'lumotlarini tozalashda yo'qolishi mumkin; zaxira nusxa oling.
- Birinchi ochishda telefon/login/parolni o'zingiz belgilang. Kirishda admin/kassir rejimi tanlanadi. Bu mahalliy prototip; haqiqiy xavfsizlik uchun server autentifikatsiyasi kerak.
- PIN sinov uchun 1234; real ishlatishdan oldin albatta almashtirish talab etiladi.
- Vaqt hisoblash hozircha soat bo'yicha yuqoriga yaxlitlanadi. Tungi tarif oynasi sozlamada saqlanadi, lekin alohida tungi narx qoidasini keyingi iteratsiyada kiritish kerak.
- Bu dastlabki to'liq funksional prototip; haqiqiy kassada ishlatishdan oldin test qiling.
