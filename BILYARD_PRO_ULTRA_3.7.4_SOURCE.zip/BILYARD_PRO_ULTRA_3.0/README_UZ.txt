BILYARD PRO ULTRA 3.7.3 — Android Studio loyiha manbasi

Ushbu versiyadagi o'zgarishlar:
1. Seans vaqti HH:MM:SS ko'rinishida sekundma-sekund yangilanadi.
2. Xizmat haqi o'tgan aniq sekund asosida hisoblanadi: soatlik narx / 3600 * o'tgan sekund.
3. Narxi 0 yoki belgilanmagan mahsulot bosilganda narx kiritish oynasi chiqadi; kiritilgan narx saqlanadi.
4. Mahsulot miqdori so'raladi va jami narx ko'rsatiladi.
5. Menyu yuqori chapdagi ⋮ tugmasiga ko'chirildi; bosilganda yon panel ochiladi.
6. Bilyard, PlayStation, Kompyuter, Mijoz qarzi va Sozlamalar yon menyuda mavjud.

Loyiha Android Studio orqali ochiladi. APK uchun app modulida assembleDebug ishga tushiriladi.
Dastlabki kirish kodi: 1234.
