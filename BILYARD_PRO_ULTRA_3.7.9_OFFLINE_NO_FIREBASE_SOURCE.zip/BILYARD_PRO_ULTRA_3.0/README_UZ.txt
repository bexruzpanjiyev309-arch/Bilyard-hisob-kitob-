BILYARD PRO ULTRA 3.7.9 - OFFLINE

Firebase va litsenziya serveri olib tashlandi. Ilova ochilganda to'g'ridan-to'g'ri ishga tushadi.
Internet ulanishi talab qilinmaydi.

Mavjud HTML ilova funksiyalari:
- Oddiy va Premium bilyard stollari, alohida narxlar
- PS3/PS4 umumiy narxi, PS5 alohida narxi
- Kompyuterlar
- Har bir xizmatni boshlashda mijoz ismini so'rash
- Ism faol seans, chek va hisobotda ko'rsatiladi
- A4 chop etish

Eslatma: ma'lumotlar ushbu qurilmaning localStorage xotirasida saqlanadi.
Telefonni almashtirishdan oldin ilova ichidagi zaxira nusxasini oling.
